#include "StudentWorld.h"
#include "GameConstants.h"
#include "Actor.h"
#include <iostream>
#include <sstream>
#include <string>
#include <vector>
#include <cmath>
using namespace std;

GameWorld* createStudentWorld(string assetPath) {
	return new StudentWorld(assetPath);
}

// Students:  Add code to this file, StudentWorld.h, Actor.h and Actor.cpp
StudentWorld::StudentWorld(string assetPath)
: GameWorld(assetPath) {}

//Destructor, calls cleanup
StudentWorld::~StudentWorld() {
    cleanUp();
}

//Looks for an obj that w/in Euclidean distance of (x,y) that can be damaged by spray/flame
//Ff finds + damages one returns true otherwise returns false
bool StudentWorld::hitObject(double x, double y, int hit) {
    vector<Actor*>::iterator itr = m_actors.begin();

    //Loop through all Actors
    while (itr != m_actors.end()) {
        //If find Actor that is vulnerable to spray/flame, damage + return true if Actor w/in distance
        if ((*itr)->takesProjectileDamage()) {
            if (withinDistance(x, y, (*itr)->getX(), (*itr)->getY(), SPRITE_WIDTH)) {
                (*itr)->projectileDamage(hit); //If Actor has HP will -= hp, otherwise sets it to dead
                return true;
            }
        }
        itr++;
    }

    return false; //Didn't find an Actor to damage, return false
}

//Adds new Actor to world
void StudentWorld::addActor(Actor* a) {
    m_actors.push_back(a);
}

//Returns true if Actor at (x1, y1) overlaps w/ Socrates
bool StudentWorld::overlapWithSocrates(double x1, double y1) const {
    return withinDistance(x1, y1, m_soc->getX(), m_soc->getY(), SPRITE_WIDTH);
}

//Adds points to user's score
void StudentWorld::addScorePoints(int points) {
    increaseScore(points);
}

//Damage Socrates' hp by hit points, plays correct sound for Socrates damage/die
void StudentWorld::damageSocrates(int hit) {
    m_soc->addHP(hit);
    if (m_soc->getHP() > 0)
        playSound(SOUND_PLAYER_HURT);
    else
        playSound(SOUND_PLAYER_DIE);
}

//Restore Socrate's health points to full if pick up RestoreHealthGoodie
void StudentWorld::restoreSocratesHealth() {
    m_soc->restoreHP();
}

//Give Socrates +5 flame thrower charges
void StudentWorld::addSocratesFlame() {
    m_soc->addFlameThrower();
}


//Return true if find + eat Food w/in SPRITE_WIDTH/2 distance of Bacteria at (x1, y1)
//Return false if didn't find Food
bool StudentWorld::eatFood(double x1, double y1) {
    vector<Actor*>::iterator itr = m_actors.begin();

    //Loop through all current actors in World + look for Food
    while (itr != m_actors.end()) {
        if ((*itr)->isEdible() && (*itr)->isAlive()) {
            //If find Food w/in distance, set Food to dead + return true to eat it
            if (withinDistance(x1, y1, (*itr)->getX(), (*itr)->getY(), SPRITE_WIDTH / 2)) {
                (*itr)->setDead();
                return true;
            }
            else
                itr++;
        }
        else //Otherwise, continue searching
            itr++;
    }

    return false; //Return false if went through all Actors and didn't find edible food
}

//Returns true if found Food that Bacteria can eat w/in 128 pixels of (x1, y1) + sets x1, y1 to location of closest Food
//Returns false + doesn't change x1, y1 if doesn't find Food
bool StudentWorld::findClosestFood(double& x1, double& y1) {
    vector<Actor*>::iterator itr = m_actors.begin();
    bool found = false;
    double minDistance = 128;

    //Loop through all current actors
    while (itr != m_actors.end()) {
        //If find Food w/in distance, set x1, y1 to coordinates of Food if have smallest dist found + set found to true
        if ((*itr)->isEdible() && (*itr)->isAlive()) {
            if (withinDistance(x1, y1, (*itr)->getX(), (*itr)->getY(), VIEW_RADIUS)) {
                //Check that closer than other Foods found
                if (getDistance(x1, y1, (*itr)->getX(), (*itr)->getY()) <= minDistance) {
                    minDistance = getDistance(x1, y1, (*itr)->getX(), (*itr)->getY());
                    x1 = (*itr)->getX();
                    y1 = (*itr)->getY();
                }
                found = true;
            }
        }

        itr++;
    }

    return found; //If didn't find Food, return false w/o changing x1, y1
}

//Checks if Bacteria at (x1, y1) is within <= SPRITE_WIDTH/2 dist from any Dirt obj
bool StudentWorld::overlapWithDirt(double x1, double y1) {
    vector<Actor*>::iterator itr = m_actors.begin();
    
    //Loop through all current Actors
    while (itr != m_actors.end()) {
        if ((*itr)->blocksBacteria() && (*itr)->isAlive()) {
            //If find Dirt w/in distance, return true
            if (withinDistance(x1, y1, (*itr)->getX(), (*itr)->getY(), SPRITE_WIDTH / 2))
                return true;
            else
                itr++;
        }
        else
            itr++;
    }

    return false;
}

//Return true if Socrates within d pixels of Bacteria @ (x1, y1) + sets x1, y1 to Socrates loc
//Return false + doesn't change x1, y1 otherwise
bool StudentWorld::findSocrates(double& x1, double& y1, int d) const {
    //If found Socrates w/in distance, set x1 + y1 to Socrate's loc + return true
    if (withinDistance(x1, y1, m_soc->getX(), m_soc->getY(), d)) {
        x1 = m_soc->getX();
        y1 = m_soc->getY();
        return true;
    }

    return false; //If Socrates isn't w/in dist, return false w/out changing x1 + y1
}

//Return distance btw (x1, y1) + (x2, y2)
double StudentWorld::getDistance(double x1, double y1, double x2, double  y2) const {
    double distance = (x1 - x2) * (x1 - x2);
    distance += (y1 - y2) * (y1 - y2);
    distance = sqrt(distance);

    return distance;
}

//Returns true if distance btw (x1, x2) and centre < d
bool StudentWorld::withinDistanceCentre(double x1, double y1, int d) const {
    double dist = getDistance(x1, y1, VIEW_WIDTH / 2, VIEW_HEIGHT / 2);

    return dist < d; //If distance 
}

//Returns true if  Euclidean distance btw (x1, x2) + (y1, x2) <= d
bool StudentWorld::withinDistance(double x1, double y1, double x2, double y2, int d) const {
    double dist = getDistance(x1, y1, x2, y2);

    return dist <= d; //If distance 
}

int StudentWorld::init() {
    m_soc = new Socrates(this); //Create new Socrates

    //Generates L# of Pits @ random loc <= 120 pixels from centre (VIEW_WIDTH/2, VIEW_HEIGHT/2), Pits can't overlap w/ other Pits
    for (int i = 0; i < getLevel(); i++) {
        //cerr << "pit i = " << i << endl;
        //Create new Pit pointer w Pit @ random (x,y) 120 pixels away from centre
        int a = randInt(0, 360); //Random angle
        int r = randInt(0, 120); //Random radius

        Pit* p = new Pit(this, VIEW_WIDTH / 2 + r * cos(a * PI / 180.0), VIEW_HEIGHT / 2 + r * sin(a * PI / 180.0));
        
        //Loop through all current actors to see if any Pits new Pit would overlap w/
        vector<Actor*>::iterator itr = m_actors.begin();
        while (itr != m_actors.end()) {
            if ((*itr)->blocksNewPits()) { //Actors blocks new Pit, check for overlap
               //If overlap, break out of checking loop + decrement to make new Pit in diff loc
                if (withinDistance((*itr)->getX(), (*itr)->getY(), p->getX(), p->getY(), SPRITE_WIDTH)) {
                    i--;
                   // cerr << "blocks new pit! " << i << endl;
                    break;
                }
            }
            itr++;
        }

        if (itr == m_actors.end()) //Checked all actors, didn't find any Pit overlap
            m_actors.push_back(p);
        else
            delete p; //Found overlap, delete so no memory leak and try again
    }

    //Generates min(5L, 25) # of Food obj at random loc, Food can't overlap w/ prev Food/Pits by SPRITE_WIDTH
    int numFood = min(5 * getLevel(), 25);
    for (int i = 0; i < numFood; i++) {
        //Create new Food pointer w/ Food at random (x, y) 120 pixels away from centre
        int a = randInt(0, 360); //Random angle
        int r = randInt(0, 120);
        Food* f = new Food(this, VIEW_WIDTH / 2 + r * cos(a * PI / 180.0), VIEW_HEIGHT / 2 + r * sin(a * PI / 180.0));

        //Loop through all current actors to see if any Food/BacterialPits new Food would overlap w/
        vector<Actor*>::iterator itr = m_actors.begin();
        while (itr != m_actors.end()) {
            if ((*itr)->blocksNewFood()) { //Actors blocks new Food, check for overlap
                //If overlap, break out of checking loop + decrement to make new Food in diff loc
                if (withinDistance((*itr)->getX(), (*itr)->getY(), f->getX(), f->getY(), SPRITE_WIDTH)) {
                    i--;
                    break;
                }
            }
            itr++;
        }

        if (itr == m_actors.end()) //Checked all actors, didn't find any food overlap
            m_actors.push_back(f);
        else
            delete f; //Found overlap, delete so no memory leak and try again
    }

    //Generates max(180-20L, 20) # of Dirt obj in random loc, Dirt can't overlap w/ prev-place food/pits
    int numDirt = max(180 - 20 * getLevel(), 20);
    for (int i = 0; i < numDirt; i++) {
        //Create new Dirt pointer w/ Dirt at random (x, y) 120 pixels away from centre
        int a = randInt(0, 360); //Random angle
        int r = randInt(0, 120); //Random radius
        Dirt* d = new Dirt(this, VIEW_WIDTH / 2 + r * cos(a * PI / 180.0), VIEW_HEIGHT/2 + r * sin(a * PI / 180.0));

        //Loop through all current actors to see if there are Food/BacterialPits new Dirt would overlap w/
        vector<Actor*>::iterator itr = m_actors.begin();
        while (itr != m_actors.end()) {
            if ((*itr)->blocksNewDirt()) { //If Actor blocks new Dirt, check for overlap
                //If overlap, break out of checking loop + decrement to make new Dirt in diff loc
                if (withinDistance((*itr)->getX(), (*itr)->getY(), d->getX(), d->getY(), SPRITE_WIDTH)) {
                    i--;
                    break;
                }
            }
            itr++; //If Actor doesn't block new Dirt, check rest of Actors
        }

        if (itr == m_actors.end()) //Checked all Actors, didn't find any overlap
            m_actors.push_back(d);
        else
            delete d; //Deallocates if not added to m_actors (if added, sb deleted later w/ cleanUp)
    } //End of make Dirt loop

    /*Bacteria* b1 = new RegularSalmonella(this, 128, 256);
    Bacteria* b2 = new AggressiveSalmonella(this, 128, 0);
    Bacteria* b3 = new EColi(this, 256, 128);
    m_actors.push_back(b1);
    m_actors.push_back(b2);
    m_actors.push_back(b3); */

    return GWSTATUS_CONTINUE_GAME;
}

int StudentWorld::move() {
    bool levelCompleted = true;

    //Loop through every actor in m_actors + call their doSomething method, also call Socrates
    m_soc->doSomething();

    vector<Actor*>::iterator itr;
    itr = m_actors.begin();
    while (itr != m_actors.end()) {
        (*itr)->doSomething();

        //If Bacteria/Pit still active, level hasn't been completed
        if ((*itr)->isAlive() && (*itr)->preventsLevelCompleting())
            levelCompleted = false;

        //If Socrates has died, return player died + delete Socrates
        if (!m_soc->isAlive()) {
            decLives();
            delete m_soc;
            m_soc = nullptr;
            return GWSTATUS_PLAYER_DIED;
        }

        itr++;
    }

    //If Socrates is alive + level has been completed, return that player finished level
    if (m_soc->isAlive() && levelCompleted) {
        delete m_soc;
        m_soc = nullptr;
        playSound(SOUND_FINISHED_LEVEL);
        return GWSTATUS_FINISHED_LEVEL;
    }

    //Delete any Actors that have died
    itr = m_actors.begin();
    while (itr != m_actors.end()) {
        if (!(*itr)->isAlive()) { //If Actor is dead
            delete (*itr); //Delete pointer itr points to
            itr = m_actors.erase(itr); //Erase element from m_actors vector
        }
        else
            itr++;
    }

    //Add new Goodies
    int lifetime = max(randInt(0, 300 - 10 * getLevel() - 1), 50);
    //Add new Fungus @ random angle, location VIEW_RADIUS away from centre of dish if chanceFungus = 0
    int chanceFungus = max(510 - getLevel() * 10, 200);
    chanceFungus = randInt(0, chanceFungus);
    if (chanceFungus == 0) {
        int af = randInt(0, 360);
        double rx = VIEW_WIDTH / 2 + VIEW_RADIUS * cos(af * PI / 180.0);
        double ry = VIEW_HEIGHT / 2 + VIEW_RADIUS * sin(af * PI / 180.0);
        Fungus* fu = new Fungus(this, rx, ry, lifetime);
        m_actors.push_back(fu);
    }
    
    lifetime = max(randInt(0, 300 - 10 * getLevel() - 1), 50);
    //Add new Goodies @ random angle, loc VIEW_RADIUS away from centre of dish if chanceGoodie = 0
    int chanceGoodie = max(510 - getLevel() * 10, 250);
    chanceGoodie = randInt(0, chanceGoodie);
    if (chanceGoodie == 0) {
        int ag = randInt(0, 360);
        double rx  = VIEW_WIDTH / 2 + VIEW_RADIUS * cos(ag * PI / 180.0);
        double ry = VIEW_HEIGHT / 2 + VIEW_RADIUS * sin(ag * PI / 180.0);

        Goodie* g;

        int whichGoodie = randInt(1, 10);
        if (whichGoodie <= 6) //60% chance for RestoreHealthGoodie
            g = new RestoreHealthGoodie(this, rx, ry, lifetime);
        else if (whichGoodie <= 9) //30% chance for FlamethrowerGoodie
            g = new FlamethrowerGoodie(this, rx, ry, lifetime);
        else //10% chance for ExtraLifeGoodie
            g = new ExtraLifeGoodie(this, rx, ry, lifetime);

        m_actors.push_back(g);
    }
        
    //Update status text w/ current info: score, level, lives, health, sprays, flames
    ostringstream status;

    //Score is 6 digits: starts as 000000
    //If negative: -00050
    status << "Score: ";
    int score = getScore();
    if (getScore() < 0) { //Add minus sign
        status << "-";
        score = -score;
        if (score >= 1000 && score < 10000)
            status << "0";
        else if (score >= 100)
            status << "00";
        else if (score >= 10)
            status << "000";
        else if(score < 10)
            status << "0000";
    }
    else { //Score is positive, 6 digits
        if (score >= 10000 && score < 100000)
            status << "0";
        else if (score >= 1000)
            status << "00";
        else if (score >= 100)
            status << "000";
        else if (score >= 10)
            status << "0000";
        else if (score < 10)
            status << "00000";
    }

    status << score << "  ";
    status << "Level: " << getLevel() << "  ";
    status << "Lives: " << getLives() << "  ";
    status << "Health: " << m_soc->getHP() << "  ";
    status << "Sprays: " << m_soc->getNumSpray() << "  ";
    status << "Flames: " << m_soc->getNumFlame();
    setGameStatText(status.str());

    return GWSTATUS_CONTINUE_GAME;
}

void StudentWorld::cleanUp() {
   // cerr << "cleanUp() called" << endl;

    vector<Actor*>::iterator itr;
    itr = m_actors.begin();
    
    while (itr != m_actors.end()) {
        delete (*itr); //Delete pointer itr points to
        itr = m_actors.erase(itr); //Erase itr in map and point it to next element
    }

    delete m_soc;

    //cerr << "cleanUp over" << endl;
}
