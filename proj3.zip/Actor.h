#ifndef ACTOR_H_
#define ACTOR_H_

class StudentWorld;
#include "GraphObject.h"

// Students:  Add code to this file, Actor.cpp, StudentWorld.h, and StudentWorld.cpp
//-----ACTOR-----
class Actor : public GraphObject {
public:
	//Constructor, init GraphObj w/ same arg + every actor has pointer sw to StudentWorld it's in
	Actor(StudentWorld* world, int imageID, double startX, double startY, Direction dir = 0, int depth = 0, double size = 1.0)
		: GraphObject(imageID, startX, startY, dir, depth, size) {
		m_world = world;
		m_alive = true;
		m_hp = 0;
	}
	virtual ~Actor() = 0; //Pure virtual destructor

	virtual void doSomething() = 0;
	virtual void projectileDamage(int hit);
	virtual void setHP(int hp);

	virtual bool takesProjectileDamage() const = 0; //Return true if can be damaged
	virtual bool blocksBacteria() const; //Return true if blocks bacteria, default false
	virtual bool blocksProjectiles() const; //Return true if block spray/flame, default false
	virtual bool blocksNewPits() const; //Returns true if blocks new BPits from overlap w/ it, only other BacterialPits
	virtual bool blocksNewFood() const; //Returns true if blocks new Food from overlap w/ it, only Food + BacterialPits
	virtual bool blocksNewDirt() const; //Returns true if blocks new Dirt from overlapping w/ it, only Food + BacterialPits
	virtual bool hasHP() const; //Returns true if Actor has health points, default false
	virtual bool isEdible() const; //Returns true if Actor can be eaten, default false
	virtual bool preventsLevelCompleting() const; //Return true if level can't end if Actor is alive, default false

	bool isAlive() const; //Returns true if alive
	void setDead(); //Set status m_alive to false
	int getHP() const; //Return health points
	void addHP(int hp); //Add hp to Actor's hit points
	StudentWorld* getWorld() const; //Returns pointer to world

private:
	StudentWorld* m_world; //Pointer to world Actor is in
	bool m_alive;
	int m_hp;
};

//-----SOCRATES-----
class Socrates : public Actor {
public:
	Socrates(StudentWorld* world);

	virtual void doSomething();
	virtual bool takesProjectileDamage() const;
	virtual bool hasHP() const;

	void restoreHP();
	void addFlameThrower();
	int getNumSpray() const;
	int getNumFlame() const;
private:
	int m_numSpray;
	int m_numFlame;
};

//-----HEALTH----- Goodie (RestoreHealth, FlameThrower, ExtraLife) + Fungus
class Health : public Actor {
public:
	Health(StudentWorld* world, int imageID, double startX, double startY, int lifetime, int points);
	virtual bool takesProjectileDamage() const;
	virtual void doSomething();

	int getLifetime() const;
	int getLifePassed() const;
	int getPoints();
private:
	int m_lifetime;
	int m_lifePassed;
	int m_points;

	virtual void healthAction() = 0; //Specific action each subclass defines
};

class Goodie : public Health {
public:
	Goodie(StudentWorld* world, int imageID, double startX, double startY, int lifetime, int points)
		: Health(world, imageID, startX, startY, lifetime, points) {}
private:
	virtual void healthAction();
	virtual void goodieAction() = 0;
};

class RestoreHealthGoodie : public Goodie {
public:
	RestoreHealthGoodie(StudentWorld* world, double startX, double startY, int lifetime)
		: Goodie(world, IID_RESTORE_HEALTH_GOODIE, startX, startY, lifetime, 250) {}
private:
	virtual void goodieAction();
};

class FlamethrowerGoodie : public Goodie {
public:
	FlamethrowerGoodie(StudentWorld* world, double startX, double startY, int lifetime)
		: Goodie(world, IID_FLAME_THROWER_GOODIE, startX, startY, lifetime, 300) {}
private:
	virtual void goodieAction();
};

class ExtraLifeGoodie : public Goodie {
public:
	ExtraLifeGoodie(StudentWorld* world, double startX, double startY, int lifetime)
		: Goodie(world, IID_EXTRA_LIFE_GOODIE, startX, startY, lifetime, 500) {}
private:
	virtual void goodieAction();
};

class Fungus : public Health {
public:
	Fungus(StudentWorld* world, double startX, double startY, int lifetime)
		: Health(world, IID_FUNGUS, startX, startY, lifetime, -50) {}
private:
	virtual void healthAction();
};

//-----BACTERIA------ RegularSalmonella, AggressiveSalmonella, EColi
class Bacteria : public Actor {
public:
	Bacteria(StudentWorld* world, int imageID, double startX, double startY, int hp, int damagePoints);
	virtual void doSomething();
	virtual int getMovementPlanDist() const;
	virtual void setMovementPlanDist(int newDist);
	virtual void projectileDamage(int hit);

	virtual bool takesProjectileDamage() const;
	virtual bool hasHP() const;
	virtual bool preventsLevelCompleting() const;
private:
	virtual void playHurtSound() const = 0;
	virtual void playDeathSound() const = 0;
	virtual bool aggressiveMove();
	virtual void bacteriaMove() = 0;
	virtual Bacteria* createNewBacteria(double startX, double startY) const = 0;

	int m_movementPlanDist;
	int m_foodEaten;
	int m_damagePoints;
};

class Salmonella : public Bacteria {
public:
	Salmonella(StudentWorld* world, double startX, double startY, int hp, int damagePoints)
		: Bacteria(world, IID_SALMONELLA, startX, startY, hp, damagePoints) {}
private:
	virtual void playHurtSound() const;
	virtual void playDeathSound() const;
	virtual void bacteriaMove();
};

class RegularSalmonella : public Salmonella {
public:
	RegularSalmonella(StudentWorld* world, double startX, double startY)
		: Salmonella(world, startX, startY, 4, 1) {}
private:
	virtual Bacteria* createNewBacteria(double startX, double startY) const;
};

class AggressiveSalmonella : public Salmonella {
public:
	AggressiveSalmonella(StudentWorld* world, double startX, double startY)
		: Salmonella(world, startX, startY, 10, 2) {}
private:
	virtual bool aggressiveMove();
	virtual Bacteria* createNewBacteria(double startX, double startY) const;
};

class EColi : public Bacteria {
public:
	EColi(StudentWorld* world, double startX, double startY)
		: Bacteria(world, IID_ECOLI, startX, startY, 5, 4) {}
private:
	virtual void playHurtSound() const;
	virtual void playDeathSound() const;

	virtual void bacteriaMove();
	virtual Bacteria* createNewBacteria(double startX, double startY) const;
};

//----BACTERIALPIT-----
class Pit : public Actor {
public:
	Pit(StudentWorld* world, double startX, double startY);
	virtual void doSomething();
	virtual bool takesProjectileDamage() const;
	virtual bool blocksNewPits() const;
	virtual bool blocksNewFood() const;
	virtual bool blocksNewDirt() const;
	virtual bool preventsLevelCompleting() const;
private:
	int m_regS;
	int m_aggS;
	int m_EColi;
};


//-----PROJECTILE-----  Spray, Flame
class Projectile : public Actor {
public:
	Projectile(StudentWorld* world, int imageID, double startX, double startY, Direction dir, Direction moveAngle,
		int maxDist, int hit, int depth = 1)
		: Actor(world, imageID, startX, startY, dir, depth) {
		m_maxTravel = maxDist;
		m_hitPoints = hit;
		m_hasMoved = 0;
		m_moveAngle = moveAngle;
	}
	virtual void doSomething();
	virtual bool takesProjectileDamage() const;
	int getMaxTravelDistance() const;
	int getHitPoints() const;
private:
	int m_maxTravel;
	int m_hitPoints; //points of damage done to obj
	int m_hasMoved; //pixels Proj has moved
	Direction m_moveAngle; //direction to move in, only diff for Flame
};

class Spray : public Projectile {
public:
	Spray(StudentWorld* world, double startX, double startY, Direction dir, Direction moveAngle)
		: Projectile(world, IID_SPRAY, startX, startY, dir, moveAngle, 112, 2) {}
};

class Flame : public Projectile {
public:
	Flame(StudentWorld* world, double startX, double startY, Direction dir, Direction moveAngle)
		: Projectile(world, IID_FLAME, startX, startY, dir, moveAngle, 32, 5) {}
};

//-----FOOD-----
class Food : public Actor {
public:
	Food(StudentWorld* world, double startX, double startY)
		:Actor(world, IID_FOOD, startX, startY, 90, 1) {}

	virtual void doSomething(); //doesn't do anything
	virtual bool takesProjectileDamage() const;
	virtual bool blocksNewFood() const;
	virtual bool blocksNewDirt() const;
	virtual bool isEdible() const;
};

//-----DIRT-----
class Dirt : public Actor {
public:
	Dirt(StudentWorld* world, double startX, double startY)
		: Actor(world, IID_DIRT, startX, startY, 0, 1) {}

	virtual void doSomething(); //doesn't do anything
	virtual bool takesProjectileDamage() const;
	virtual bool blocksBacteria() const;
	virtual bool blocksProjectiles() const;
};

#endif // ACTOR_H_