#include "Actor.h"
#include "StudentWorld.h"
#include <iostream>
#include <vector>
#include <cmath>
using namespace std;

// Students:  Add code to this file, Actor.h, StudentWorld.h, and StudentWorld.cpp
//-----ACTOR-----
//Virtual destructor, need to have body bc C++ is dumb
Actor::~Actor() {}

//If Actor has health points, decreases hp by hit amount when hit by Spray/Flame
//Otherwise, set Actor to dead
void Actor::projectileDamage(int hit) {
	//If can't be damaged by projectiles, immediately return
	if (!(this->takesProjectileDamage()))
		return;

	if (this->hasHP()) { //If Actor has hp, damage hp
		m_hp -= hit;
		if (m_hp <= 0) //If hp <= 0, now dead
			this->setDead();
	}
	else
		this->setDead(); //Otherwise, Actor is now dead
}

//Returns true if blocks newly-created BPits from overlap w/ it, only true for other BacterialPits
bool Actor::blocksNewPits() const {
	return false;
}

//Returns true if newly-created Food can't overlap w/ this Actor, only true for Food + BacterialPits
bool Actor::blocksNewFood() const {
	return false;
}
//Returns true if newly-created dirt can't overlap w/ this Actor, only true for Food + BacterialPits
bool Actor::blocksNewDirt() const {
	return false;
}

//Returns true if blocks bacteria
bool Actor::blocksBacteria() const {
	return false;
}

//Return true if block spray/flames
bool Actor::blocksProjectiles() const {
	return false;
}

//Returns true if Actor has health points, default false
bool Actor::hasHP() const {
	return false;
}

//Return true if Actor can be eaten, only true for Food default false
bool Actor::isEdible() const {
	return false;
}

//Returns true if level can't end if Actor is alive, only true for Bacteria + Pit
bool Actor::preventsLevelCompleting() const {
	return false;
}

//Returns true if Actor is alive, false if actor is dead
bool Actor::isAlive() const {
	return m_alive;
}

//Changes Actor's status to dead
void Actor::setDead() {
	m_alive = false;
}

//Return Actor's health points
int Actor::getHP() const {
	return m_hp;
}

//Set Actor's health points
void Actor::setHP(int hp) {
	m_hp = hp;
}

//Add/subtracts from Actor's health points
void Actor::addHP(int hp) {
	m_hp += hp;

	if (m_hp <= 0) { //If m_hp = 0, Actor has died
		this->setDead();
		//cerr << "actor has died" << endl;
	}
}

//Returns pointer to world Actor is in
StudentWorld* Actor::getWorld() const {
	return m_world;
}

//-----SOCRATES-----
Socrates::Socrates(StudentWorld* world)
	: Actor(world, IID_PLAYER, 0, VIEW_HEIGHT / 2) { //Starts @ angle = 180 w/ x=0 y=128
	m_numSpray = 20;
	m_numFlame = 5;
	this->setHP(100);
}

bool Socrates::takesProjectileDamage() const {
	return true;
}

bool Socrates::hasHP() const {
	return true;
}

void Socrates::doSomething() {
	if (!isAlive()) { //If Socrates is dead, return w/o doing anything
		//cerr << "Socrates has died" << endl;
		return;
	}

	int key;
	//If getKey returns true, key was pressed so perform action according to key
	if(getWorld()->getKey(key)) {
		const double PI = 4 * atan(1);
		double newX = VIEW_WIDTH/2, newY = VIEW_HEIGHT/2;

		switch (key) {
		case KEY_PRESS_LEFT: //Left, move +5 degrees (counterclockwise)
			setDirection(getDirection() + 5);
			newX += VIEW_RADIUS*cos(((getDirection() - 180.0) * PI) / 180);
			newY += VIEW_RADIUS*sin(((getDirection() - 180.0) * PI) / 180);
			moveTo(newX, newY);
			//cerr << "direction: " << getDirection() << " x: " << newX << " y: " << newY << endl;
			break;
		case KEY_PRESS_RIGHT: //Right, move -5 degrees (clockwise)
			setDirection(getDirection() - 5);
			newX += VIEW_RADIUS * cos(((getDirection() - 180.0) * PI) / 180);
			newY += VIEW_RADIUS * sin(((getDirection() - 180.0) * PI) / 180);
			moveTo(newX, newY);
			break;
		case KEY_PRESS_SPACE: //Add spray if any spray left
			if (m_numSpray > 0) {
				//Add Spray SPRITE_WIDTH in front of Socrates, in same dir Socrates facing
				getPositionInThisDirection(getDirection(), SPRITE_WIDTH, newX, newY);
				Spray* s = new Spray(getWorld(), newX, newY, getDirection(), getDirection());
				getWorld()->addActor(s);

				//Decrement spray count, play SOUND_PLAYER_SPRAY
				m_numSpray--;
				getWorld()->playSound(SOUND_PLAYER_SPRAY);
			}
			break;
		case KEY_PRESS_ENTER: //Add 16 flames if any flame thrower left
			if (m_numFlame > 0) {
				//Add 16 Flames SPRITE_WIDTH in front of Socrates, w/ same dir + @ 22 degree increments
				for (int i = 0; i < 16; i++) {
					getPositionInThisDirection(getDirection() + i * 22, SPRITE_WIDTH, newX, newY);
					Flame* f = new Flame(getWorld(), newX, newY, getDirection(), getDirection() + i*22);
					getWorld()->addActor(f);
				}

				//Decrement flame count, play SOUND_PLAYER_FIRE
				m_numFlame--;
				getWorld()->playSound(SOUND_PLAYER_FIRE);
			}
			break;
		case KEY_PRESS_DOWN: //If press up, down, or tab don't do anything
		case KEY_PRESS_UP:
		case KEY_PRESS_TAB:
			break;
		}		
	}
	else { //If no key pressed, ++spray count if Socrates has less than max 20 sprays
		if (m_numSpray < 20)
			m_numSpray++;
	}
}

//Set hp to full
void Socrates::restoreHP() {
	this->setHP(100);
}

//Add 5 flame thrower charges if pick up flamethrower goodie
void Socrates::addFlameThrower() {
	m_numFlame += 5;
}

//Return number of Spray projectiles Socrates has left
int Socrates::getNumSpray() const {
	return m_numSpray;
}

//Return number of Flame projectiles Socrates has left
int Socrates::getNumFlame() const {
	return m_numFlame;
}

//-----HEALTH----- Goodie (RestoreHealth, FlameThrower, ExtraLife) + Fungus
Health::Health(StudentWorld* world, int imageID, double startX, double startY, int lifetime, int points)
	: Actor(world, imageID, startX, startY, 0, 1) {
	m_lifetime = lifetime;
	m_lifePassed = 0;
	m_points = points;
}

int Health::getLifetime() const {
	return m_lifetime;
}

bool Health::takesProjectileDamage() const { //True, but no HP so if hit will die
	return true;
}

int Health::getLifePassed() const {
	return m_lifePassed;
}

int Health::getPoints() { //Return points to decrease/increase score
	return m_points;
}

//If dead, immediately return
//Otherwise, if overlap w/ Socrates add score points + set state to dead
//Do action particular to Goodie
//Check if lifetime expired
void Health::doSomething() {
	if(!(this->isAlive())) //If dead, return w/o doing anything
		return;

	m_lifePassed++; //Each tick, increment lifePassed

	//If the Actor overlaps w/ Socrates, update score + set Actor to dead + do action 
	if (getWorld()->overlapWithSocrates(getX(), getY())) {
		getWorld()->addScorePoints(m_points);
		this->setDead();
		//Subclass-specific action
		healthAction();
		return;
	}

	if (getLifePassed() >= getLifetime()) //If life passed >= lifetime, lifetime has expired so Goodie is dead
		setDead();
}

//Play Goodie Sound + call subclass-specific action
void Goodie::healthAction() {
	getWorld()->playSound(SOUND_GOT_GOODIE);
	goodieAction();
}

//Restore Socrate's hp to full
void RestoreHealthGoodie::goodieAction() {
	getWorld()->restoreSocratesHealth();
}

//Add 5 flamethrower charges to Socrates
void FlamethrowerGoodie::goodieAction() {
	getWorld()->addSocratesFlame();
}

//Give user one more life
void ExtraLifeGoodie::goodieAction() {
	getWorld()->incLives();
}

//If Fungus overlaps w/ Socrates, user score decreases by 50
//Socrates is damaged by 20 points
void Fungus::healthAction() {
	getWorld()->damageSocrates(-20);
}

//-----BACTERIA------ RegularSalmonella, AggressiveSalmonella, EColi
Bacteria::Bacteria(StudentWorld* world, int imageID, double startX, double startY, int hp, int damagePoints)
	: Actor(world, imageID, startX, startY, 90, 0) {
	this->setHP(hp);
	m_movementPlanDist = 0;
	m_foodEaten = 0;
	m_damagePoints = damagePoints;
}


bool Bacteria::takesProjectileDamage() const {
	return true;
}
bool Bacteria::hasHP() const {
	return true;
}
bool Bacteria::preventsLevelCompleting() const {
	return true;
}

bool Bacteria::aggressiveMove() {
	return false;
}
int Bacteria::getMovementPlanDist() const {
	return m_movementPlanDist;
}

void Bacteria::setMovementPlanDist(int newDist) {
	m_movementPlanDist = newDist;
}

void Bacteria::projectileDamage(int hp) {
	this->addHP(-hp);

	if (isAlive()) //If Bacteria still alive, play hurt sound
		playHurtSound();
	else { //If dead, set state to dead + play death sound + increase player's score by 100 + maybe turn into Food
		setDead();
		playDeathSound();
		getWorld()->increaseScore(100);

		//50% of Bacteria turning into Food ==> if turn into Food, add new Food obj at (x, y) in world
		int chanceF = randInt(0, 1);
		if (chanceF == 0) {
			Food* f = new Food(getWorld(), this->getX(), this->getY());
			getWorld()->addActor(f);
		}
	}
}

void Bacteria::doSomething() {
	if (!isAlive()) //If Bacteria is dead, immediately return
		return;

	//If Bacteria is AggSalm, will look for Socrates + move towards if found + return true, return false if not found
	//If Bacteria isn't AS, will only return false
	bool ag = aggressiveMove();

	//If overlap w/ Socrates, damage Socrates by Bacteria's hit points
	if (getWorld()->overlapWithSocrates(getX(), getY()))
		getWorld()->damageSocrates(-m_damagePoints);
	else { //If don't overlap w/ Socrates, check for Food
		if (m_foodEaten == 3) { //If ate 3 Food, add another Bacteria obj of same type at new coord
			double newX = getX();
			if (newX < VIEW_WIDTH / 2)
				newX += SPRITE_WIDTH / 2;
			else if (newX > VIEW_WIDTH / 2)
				newX -= SPRITE_WIDTH / 2;
			 
			double newY = getY();
			if (newY < VIEW_HEIGHT / 2)
				newY += SPRITE_WIDTH / 2;
			else if (newY > VIEW_HEIGHT / 2)
				newY -= SPRITE_WIDTH / 2;

			Bacteria* b = createNewBacteria(newX, newY);
			getWorld()->addActor(b);
			m_foodEaten = 0; //Reset foodEaten
		}
		else { //If hasn't eaten 3 Food, look for food to eat
			if (getWorld()->eatFood(getX(), getY()))
				m_foodEaten++;
		}
	}

	if (!ag)
		bacteriaMove();
}

//If movement plan dist > 0, move forward by 3 pixels in current dir unless blocked by Dirt/go out of dish
//If movement plan dist > 0 but blocked from move forward, set dir to random dir and reset movement plan dist to 10
void Salmonella::bacteriaMove() {
	//If movement plan dist > 0, decrement dist + try to move forward by 3 pixels in current dir
	if (getMovementPlanDist() > 0) {
		setMovementPlanDist(getMovementPlanDist() - 1); //Decrement movement plan dist

		double newX = 0, newY = 0;
		getPositionInThisDirection(getDirection(), 3, newX, newY);

		//Move if can move forward 3 pixels in current dir: can't if would overlap w/ Dirt or go out of bounds
		if (!getWorld()->overlapWithDirt(newX, newY) && getWorld()->withinDistanceCentre(newX, newY, VIEW_RADIUS))
			moveTo(newX, newY);
		//If can't move forward, pick random dir to mov in + set new dir + reset movement plan dist to 10
		else {
			double newAngle = randInt(0, 360);
			this->setDirection(newAngle);
			this->setMovementPlanDist(10);
		}
		return;
	}
	//Otherwise, look for closest Food w/in 128 pixel
	else {
		double newX = getX(), newY = getY();
		//If found Food, try to move 3 pixels toward Food: can't move if would overlap w/ Dirt
		if (getWorld()->findClosestFood(newX, newY)) {
			double newAngle = atan2(newY-getY(), newX-getX()) * 180.0 / (4 * atan(1)); //newAngle = inverse tan(y/x) in degrees
			getPositionInThisDirection(newAngle, 3, newX, newY);

			//If new pos would overlap w/ Dirt, pick random dir + set new dir + reset movement plan dist to 10
			if (getWorld()->overlapWithDirt(newX, newY)) {
				newAngle = randInt(0, 360);
				this->setDirection(newAngle);
				this->setMovementPlanDist(10);
				return;
			}
			else {
				this->setDirection(newAngle);
				moveTo(newX, newY);
			}
		}
		//If doesn't find food, pick ranodm dir + set new dir + reset movement plan dist to 10
		else {
			Direction newAngle = randInt(0, 360);
			this->setDirection(newAngle);
			this->setMovementPlanDist(10);
			return;
		} 
	}
}

//If AS <= 72 pixels away from Socrates, will try to move 3 pixels towards Socrates
bool AggressiveSalmonella::aggressiveMove() {
	double newX = getX(), newY = getY();

	if (getWorld()->findSocrates(newX, newY, 72)) { //newX, newY changed by findSocrates
		double newAngle = atan2(newY - getY(), newX - getX()) * 180.0 / (4 * atan(1)); //newAngle = inverse tan(y/x) in degrees
		getPositionInThisDirection(newAngle, 3, newX, newY); //newX, newY changed again by getPos()

		//If not blocked by Dirt, move towards Socrates 
		if (!getWorld()->overlapWithDirt(newX, newY)) {
			setDirection(newAngle); 
			moveTo(newX, newY);
		}

		return true; //If Socrates w/in dist, return true so bacteriaMove() doesn't perform step 6
	}

	return false; //If didn't find Socrates, return false
}

//Return new RS @ location (startX, startY)
Bacteria* RegularSalmonella::createNewBacteria(double startX, double startY) const {
	return new RegularSalmonella(getWorld(), startX, startY);
}

//Return new AS @ location (startX, startY)
Bacteria* AggressiveSalmonella::createNewBacteria(double startX, double startY) const {
	return new AggressiveSalmonella(getWorld(), startX, startY);
}

//If EColi <= 256 pixels away from Socrates ==> if so, will get angle towards Socrates
void EColi::bacteriaMove() {
	double newX = getX(), newY = getY();

	//If Socrates w/in 256 pixels
	if (getWorld()->findSocrates(newX, newY, VIEW_RADIUS * 2)) {
		//Get angle towards Socrates + pos in that direction
		double theta = atan2(newY - getY(), newX - getX()) * 180.0 / (4 * atan(1)); //newAngle = inverse tan(y/x) in degrees
		
		//Try up to 10 times to move towards Socrates: can't if blocked by Dirt
		for (int i = 0; i < 10; i++) {
			getPositionInThisDirection(theta, 2, newX, newY);

			//If can move forward 2 pixels in dir of Socrates, move + return
			if (!getWorld()->overlapWithDirt(newX, newY)) {
				this->setDirection(theta);
				moveTo(newX, newY);
				return;
			}
			//Otherwise, increase theta by 10 degrees (wrap around at 360)
			else {
				theta += 10;
				if (theta > 360)
					theta = theta - 360;
			}
		} //end of for loop
	}
}

//Play sounds when Salmonella damaged/dies
void Salmonella::playHurtSound() const {
	getWorld()->playSound(SOUND_SALMONELLA_HURT);
}
void Salmonella::playDeathSound() const {
	getWorld()->playSound(SOUND_SALMONELLA_DIE);
}

//Play souds when EColi damaged/dies
void EColi::playHurtSound() const {
	getWorld()->playSound(SOUND_ECOLI_HURT);
}
void EColi::playDeathSound() const {
	getWorld()->playSound(SOUND_ECOLI_DIE);
}

//Return new EColi obj @ (startX, startY)
Bacteria* EColi::createNewBacteria(double startX, double startY) const {
	return new EColi(getWorld(), startX, startY);
}

//-----BACTERIALPIT-----
Pit::Pit(StudentWorld* world, double startX, double startY)
	: Actor(world, IID_PIT, startX, startY, 0, 1) {
	//Pits start w/ 5 RS, 3 AS, 2 EColi
	m_regS = 5;
	m_aggS = 3;
	m_EColi = 2;
}

bool Pit::takesProjectileDamage() const {
	return false;
}
bool Pit::blocksNewPits() const {
	return true;
}
bool Pit::blocksNewFood() const {
	return true;
}
bool Pit::blocksNewDirt() const {
	return true;
}
bool Pit::preventsLevelCompleting() const {
	return true;
}

//If Pit is empty, set dead
//Otherwise, 1/50 chance each tick that Pit will emit a Bacteria
void Pit::doSomething() {
	//If Pit has emitted all Bacteria, set dead
	if ((m_regS + m_aggS + m_EColi) == 0) {
		this->setDead();
		return;
	}

	int chanceBact = randInt(1, 50);

	//1/50 chance each tick of emitting Bacteria
	if (chanceBact == 1) {
		bool createdBact = false;

		while (!createdBact) {
			int typeB = randInt(1, 3);
			if (typeB == 1) { //Create new RegSalmonella unless no more in Pit + decrement count
				if (m_regS > 0) {
					getWorld()->addActor(new RegularSalmonella(getWorld(), getX(), getY()));
					createdBact = true;
					m_regS--;
					//cerr << "emitted 1 RS" << endl;
				}
				else //If no more RS, skip rest of code and go into next iteration of loop
					continue;
			}
			else if (typeB == 2) {
				if (m_aggS > 0) {
					getWorld()->addActor(new AggressiveSalmonella(getWorld(), getX(), getY()));
					createdBact = true;
					m_aggS--;
					//cerr << "emitted 1 AS" << endl;
				}
				else
					continue;
			}
			else if (typeB == 3) {
				if (m_EColi > 0) {
					getWorld()->addActor(new EColi(getWorld(), getX(), getY()));
					createdBact = true;
					m_EColi--;
					//cerr << "emitted 1 EColi" << endl;
				}
				else
					continue;
			} 
		} //End of create bacteria while loop

		//After Bacteria created, play sound
		getWorld()->playSound(SOUND_BACTERIUM_BORN);
	}
}


//-----PROJECTILE-----
bool Projectile::takesProjectileDamage() const {
	return false;
}

//Return Spray/Flame's max travel dist
int Projectile::getMaxTravelDistance() const {
	return m_maxTravel;
}

//Return Spray/Flame's hit points (damage pts done to hit obj), sb either 2 or 5
int Projectile::getHitPoints() const {
	return m_hitPoints;
}

//If dead, return
//Otherwise, check if can damage obj + damage obj if can; after damage, die
//If has moved max distance, die, otherwise move foward by SPRITE_WIDTH in current dir
void Projectile::doSomething() {
	if (!this->isAlive()) //If proj is dead, immediately return
		return;

	//Check if there is an obj in world w/in distance + can be damaged by projectile
	bool damaged = getWorld()->hitObject(this->getX(), this->getY(), this->getHitPoints());
	if (damaged) { //If successfully hit Actor, Projectile is now dead
		this->setDead();
		return;
	}
	else { //If didn't hit Actor
		double newX = -1, newY = -1;
		//Move forward in current dir by SPRITE_WIDTH
		getPositionInThisDirection(m_moveAngle, SPRITE_WIDTH, newX, newY);
		moveTo(newX, newY);
		m_hasMoved += SPRITE_WIDTH;

		if (m_hasMoved >= m_maxTravel) { //If has moved max travel dist, dies + no longer does damage
			setDead();
			return;
		}
	}
}

//-----FOOD-----
void Food::doSomething() {
	//cerr << "dirt does nothing" << endl;
}

bool Food::takesProjectileDamage() const {
	return false;
}
bool Food::blocksNewFood() const {
	return true;
}
bool Food::blocksNewDirt() const {
	return true;
}
bool Food::isEdible() const {
	return true;
}

//-----DIRT-----
void Dirt::doSomething() {
	//cerr << "dirt does nothing" << endl;
}

bool Dirt::takesProjectileDamage() const {
	return true;
}
bool Dirt::blocksBacteria() const {
	return true;
}
bool Dirt::blocksProjectiles() const {
	return true;
}