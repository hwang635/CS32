#ifndef STUDENTWORLD_H_
#define STUDENTWORLD_H_

#include "GameWorld.h"
#include <string>
#include <vector>

class Actor;
class Socrates;

// Students:  Add code to this file, StudentWorld.cpp, Actor.h, and Actor.cpp
class StudentWorld : public GameWorld {
public: 
    StudentWorld(std::string assetPath);
    virtual ~StudentWorld();
    virtual int init();
    virtual int move();
    virtual void cleanUp();

    //Looks for obj that can be damaged by spray/flame, if finds + damages one by hit + returns true otherwise returns false
    bool hitObject(double x, double y, int hit);
    void addActor(Actor* a);

    bool overlapWithSocrates(double x1, double y1) const;
    void addScorePoints(int points);
    void damageSocrates(int hit);
    void restoreSocratesHealth();
    void addSocratesFlame();

    bool eatFood(double x1, double y1);
    bool findClosestFood(double& x1, double& y1);
    bool overlapWithDirt(double x1, double y1);
    bool findSocrates(double& x1, double& y1, int d) const;

    bool withinDistanceCentre(double x1, double y1, int d) const;
    double getDistance(double x1, double y1, double x2, double y2) const;

private:
    std::vector<Actor*> m_actors; //Vector to hold all actors
    Socrates* m_soc; //Pointer to hold Socrates

    //Returns true if (x1, y1) and (x2, y2) are within d distance of each other
    bool withinDistance(double x1, double y1, double x2, double y2, int d) const;

    const double PI = 4 * atan(1);
};

#endif // STUDENTWORLD_H_
